Flashing OpenWrt
================

Turn your gateway to booting from usb mode in uboot:
`bmode usb`.

On the main computer run `uuu xiaomi_dgnwg05lm.uuu` or `uuu aqara_zhwg11lm.uuu`
to write firmware to your gateway.

On linux you have to make uuu executable `chmod +x uuu` and run commands with root privileges:
`sudo ./uuu xiaomi_dgnwg05lm.uuu` or `sudo ./uuu aqara_zhwg11lm.uuu`


In case of problems, download the latest version of uuu from https://github.com/NXPmicro/mfgtools/releases